package com.cts.chargeback.controller;

import java.util.List;

import javax.persistence.Id;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


import com.cts.chargeback.entity.User;
import com.cts.chargeback.service.UserService;


@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	UserService userService;
    
	@GetMapping("/show")
	public String showForm(){
		System.out.println("In Controller");
		/*userService.saveUser(user);*/
		return "registeradmin";
		
	}
	@PostMapping("/saveUser")
	public String saveUser(@ModelAttribute("user") User user,@RequestParam("password") String password){
		String encodePassword= new BCryptPasswordEncoder().encode(password);
		System.out.println("ENCODED PASSWORD : "+encodePassword);
		user.setPassword(encodePassword);
		userService.saveUser(user);
		
		return "redirect:/login";
		
	}
	
	/*@GetMapping("/homepage")
	public String homePage(Model model){
		List<Customer> userService.getlist();
		return "homepage";
	}*/
}
