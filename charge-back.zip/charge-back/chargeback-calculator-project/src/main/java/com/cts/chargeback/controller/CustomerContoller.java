package com.cts.chargeback.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.chargeback.entity.ChargebackDetails;
import com.cts.chargeback.entity.Customer;
import com.cts.chargeback.service.CustomerService;

@Controller
@RequestMapping("/customer")
public class CustomerContoller {
	
	@Autowired
	CustomerService customerService;
	
	@GetMapping("/list")
	public String getCustomerList(Model model){
		List<Customer> customerList=customerService.getCustomerList();
		System.out.println("LIST : "+customerList);
		model.addAttribute("customers", customerList);
		return "customerlist";
	}
	
	@GetMapping("/cbDetails")
	public String getChargeBackDetails(Model model){
		List<Object[]> chargebackDetails=customerService.getChargeBackDetailsList();
		System.out.println("CB LIST : "+chargebackDetails);
//		List<Customer> listCustomer=new ArrayList<>();
		Set<Customer> listCustomer=new HashSet<>();
		for(int i=0;i<chargebackDetails.size();i++)
		{
			listCustomer.add((Customer)(chargebackDetails.get(i)[0]));
		}
		model.addAttribute("cbDetails", listCustomer);
		return "chargebackdetails";
	}
	
	@GetMapping("/transactions")
	public String viewTransactions(@RequestParam("id") long accountNumber,Model model){
		System.out.println("A/C No. in Transaction : "+ accountNumber);
		List<ChargebackDetails> chargebackDetails=customerService.getTransactions(accountNumber);
		System.out.println("CB LIST : "+chargebackDetails );
		model.addAttribute("cbDetails", chargebackDetails);
		return "transaction";
	}
	
	@GetMapping("/add")
	public String addPayments(@RequestParam("id") long accountNumber,Model model){
		System.out.println("A/c No. "+accountNumber);
		model.addAttribute("accountNumber", accountNumber);
		return "addpayment";
	}
	
	@PostMapping("/capturePayment")
	public String savePayment(@ModelAttribute("payment") ChargebackDetails chargebackDetails,@RequestParam("accountNumber") long acc){
		System.out.println("ADD");
		System.out.println(acc);
		customerService.addPayment(chargebackDetails);
		return "redirect:/customer/list";
	}
	
	@GetMapping("/cbTransactions")
	public String getChargeBackTransactions(@RequestParam("id") long accountNumber,Model model){
		List<ChargebackDetails> listTransactions=customerService.getChargeBackTransactions(accountNumber);
		model.addAttribute("transactions", listTransactions);
		return "cb_transaction";
	}

}
