package com.cts.chargeback.config;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User.UserBuilder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.chargeback.entity.User;

@Service("userDetails")
public class UserDetailsServiceImpl implements UserDetailsService{
	
	@Autowired
	SessionFactory  sessionFactory;

	@Transactional
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		System.out.println("In loadUserByUsername");
		User user=findUser(username);
		UserBuilder builder=null;
		if(user!=null){
			builder = org.springframework.security.core.userdetails.User.withUsername(username);
		      builder.password(user.getPassword());
		      builder.authorities("ROLE_USER");
		}else{
			throw new UsernameNotFoundException("User not found.");
		}
		return builder.build();
	}

	@Transactional
	private User findUser(String username) {
		// TODO Auto-generated method stub
		User user=null;
		Session session=sessionFactory.getCurrentSession();
		user=session.get(User.class, username);
		System.out.println("USER : "+user.toString());
		
		return user;
	}
	
	

}
