package com.cts.chargeback.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="refundDetails")
public class RefundDetails {
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="t_id")
	long t_id;
	@Column(name="refundStatus")
	int refundStatus;
	@Column(name="refundAmount")
	float refundAmount;	
	@Column(name="comments")
	String comments;
	public RefundDetails(int refundStatus, float refundAmount, String comments) {
		
		this.refundStatus = refundStatus;
		this.refundAmount = refundAmount;
		this.comments = comments;
	}
   /*@Id
	@OneToOne(targetEntity=transcation.class,cascade=CascadeType.ALL)
	@JoinColumn(name="trans_id",referencedColumnName="t_id")
	private  transaction trans;
*/
	
	
	public int getRefundStatus() {
		return refundStatus;
	}

	public void setRefundStatus(int refundStatus) {
		this.refundStatus = refundStatus;
	}
	
	public float getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(float refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	/*public transaction getTrans() {
		return trans;
	}

	public void setTrans(transaction trans) {
		this.trans = trans;
	}*/

	public RefundDetails() {
		
	}

	public long getT_id() {
		return t_id;
	}


	public void setT_id(long t_id) {
		this.t_id = t_id;
	}


	@Override
	public String toString() {
		return "RefundDetails [ refundStatus=" + refundStatus + ", refundAmount=" + refundAmount
				+ ", comments=" + comments + "]";
	}
	
	
	
	

}
